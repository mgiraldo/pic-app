///<reference path='typings/jquery.d.ts' />
///<reference path='typings/history.d.ts' />
///<reference path='typings/csvToArray.d.ts' />
///<reference path='typings/cesium.d.ts' />
///<reference path='typings/spin.d.ts' />
