interface String {
    csvToArray : (object) => Array<any>;
}